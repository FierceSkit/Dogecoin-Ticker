/**
 * definitions.h: header files for definitions.cpp
*/

#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#endif  // DEFINITIONS_H